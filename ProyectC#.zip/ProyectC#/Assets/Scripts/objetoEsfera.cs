﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objetoEsfera : MonoBehaviour {
	public GameObject prefab;
	private int contador = 0;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyUp(KeyCode.I)) {
			contador = contador + 1;
			GameObject car = Instantiate(prefab, transform.position, transform.rotation) as GameObject;
			//Con esto instanciamos el elemento y le asignamos una variable
			//Ahora le damos un nombre
			car.name = "AutoX" + contador;
			//Destruir el elemento
			Destroy(car, 2f);
		}
	}
}
