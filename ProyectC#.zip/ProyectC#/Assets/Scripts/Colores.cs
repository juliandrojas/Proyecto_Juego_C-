﻿using UnityEngine;
using System.Collections;
public class Colores : MonoBehaviour
{
	// Use this for initialization
	void Start()
	{
	}
	// Update is called once per frame
	void Update()
	{
		if (Input.GetKeyDown(KeyCode.R))
		{
			GetComponent<Renderer>().material.color = Color.red;
		}
		if (Input.GetKeyDown(KeyCode.G))
		{
			GetComponent<Renderer>().material.color = Color.green;
		}
		if (Input.GetKeyDown(KeyCode.B))
		{
			GetComponent<Renderer>().material.color = Color.blue;
		}
	}
	//Colisiones-cuando ingresa a la colision
	void OnCollisionEnter(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
	//Colisiones-cuando sale a la colision
	void OnCollisionExit(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
	void OnCollisionStay(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
}