﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour {
	//si quitamos el public las variables se vuelven exclusivas del script y no se pueden manipular en el inspector
	public float deltaRotation = 30f;
	public float deltaMovement = 10f;
	// Use this for initialization
	void Start()
	{

	}
	// Update is called once per frame
	void Update()
	{

		//pon comentarios y quita comentarios para ver su funcionamiento
		/*CÃ³digo para que rote solo
    * transform.Rotate(new Vector3(0f, 30f, 0f) * Time.deltaTime);
    * */
		Rotate();
		Movement();
	}
	void Rotate()
	{
		//obtiene la tecla q, gira a la izquierda
		if (Input.GetKey(KeyCode.Q))
		{
			transform.Rotate(new Vector3(0f, -deltaRotation, 0f) * Time.deltaTime);

		}
		//obtiene la tecla e, gira a la derecha
		else if (Input.GetKey(KeyCode.E))
		{
			transform.Rotate(new Vector3(0f, deltaRotation, 0f) * Time.deltaTime);

		}
	}
	void Movement()
	{
		//adelante
		if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
		{
			transform.Translate(Vector3.forward * deltaMovement * Time.deltaTime);
		}//atras
		else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
		{
			transform.Translate(Vector3.back * deltaMovement * Time.deltaTime);
		}//izquierda
		else if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
		{
			transform.Translate(Vector3.left * deltaMovement * Time.deltaTime);
		}//derecha
		else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
		{
			transform.Translate(Vector3.right * deltaMovement * Time.deltaTime);
		}
	}
	//Colisiones-cuando ingresa a la colision
	void OnCollisionEnter(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
	//Colisiones-cuando sale a la colision
	void OnCollisionExit(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
	void OnCollisionStay(Collision collision){
		GameObject colisionado = collision.gameObject;
		Debug.Log ("Colision con " + colisionado.name);
	}
}